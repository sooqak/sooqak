export default function Home() {
  return (
    <div style={{ textAlign: 'center', marginTop: '100px' }}>
      <h1>مرحبًا بك في منصة سوقك 🚀</h1>
      <p>أول منصة عربية لبيع المنتجات الرقمية بسهولة وأمان</p>
    </div>
  );
}